# Template contract

{
  "reference": "C:\\Users\\User\\Downloads\\REPORTE SEMANAL (1).docx",
  "sha256": "b66cfcde4e0138d0bd75e5a1fe37352b499c5d67a0d51b029207898c06adb511",
  "pages": 2,
  "sections": [
    {
      "width": 7560310,
      "height": 10692130,
      "margins": [
        899795,
        1080135,
        899795,
        1080135
      ]
    }
  ],
  "parts": {
    "[Content_Types].xml": "c22c5315739af09063e93d26ada2e9d14897f1b71daff061d44311d3cad1d0c8",
    "_rels/.rels": "0fd3d935399dc6c4f2b1bfaf1bb6662bf42a7c54efee9a19da73644a7998d505",
    "word/document.xml": "75ffa37aa4b69956dd5c5647efe8e795a02cf3a6b07e9efb70dc61f5db410969",
    "word/_rels/document.xml.rels": "b2f2472b62d93b60578ec38d819c18637f51a512ce4c5bb706259d446874d01b",
    "word/footnotes.xml": "5be8ae07e79c3a9fa0b12c2a8ff7d68f3f86cdb7dcc1d56e41514f6437a5e94c",
    "word/endnotes.xml": "0ac491de4e507911a84c109adb478a3bb481d73b93bc36c8d94fc0bd3e0d23f7",
    "word/header1.xml": "e3876fdbea447e6823aadd248de8923d30dda2704c352e35f8a9dc7418a13222",
    "word/_rels/header1.xml.rels": "779c247d1b804331240a88219853bd68ebaf0b63d2ca583ce15a38e8995724b3",
    "word/media/image1.jpeg": "6cd359097dbbecab213e975d2a0364f8bfd5efbd486fb0e825a85068fb90ae30",
    "word/theme/theme1.xml": "a31bf9528324fda771b218fa70607eb8651c44bb280edd2974403756d88bb62e",
    "docProps/thumbnail.emf": "12fc625fe9b4d6a9626bda04459b1278944ad60d0b2dc9953ffab82e3a139433",
    "word/settings.xml": "38b74261132fc63b87bf55ab41a121ed82bbec06a2449e101db9e1ee9f27c68a",
    "word/styles.xml": "02c8a20f0112631f19916d031b5ccc372746e7610f15de32f43c323c09bf4a31",
    "word/webSettings.xml": "a935be2dde349160ee390cc5b6a06aa057cfd44feac230f6eff440889f53902f",
    "word/fontTable.xml": "d1cb5d1c9b60392dc0d2327ae94f9db903a88a82b4301571add1ff6557bdf697",
    "docProps/core.xml": "223169c25d015b1c6a3ce6c7ce709ba4089ad563513bb478ec01112f3ba5c849",
    "docProps/app.xml": "d13dc948ce95380ad4d288fc51d7182469c61a8d8c5ef6c442172293fc191e0f"
  },
  "preserve": "All parts except word/document.xml; keep logo header, styles, table grids, members, attendance 5/5 and time slots.",
  "slots": "Body paragraph 3 period; table 1 date/activity cells; paragraph 7 material text only; paragraph 8 total and overnight clarification. Source title and form labels control design.",
  "render": "qa/referencia/page-1.png and page-2.png; Word PDF export used because packaged render_docx.py found no bundled LibreOffice on Windows.",
  "typography": "Inherited source runs and paragraph properties; no generic styles or font substitution."
}